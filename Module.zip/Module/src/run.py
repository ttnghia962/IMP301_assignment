import cv2
from module import Module


if __name__ == "__main__":
    module = Module(model="/home/tuan/Documents/Module/weights/classify.pt")

    image = cv2.imread("/home/tuan/Documents/Module/dataset/test3.jpg")

    emotion = module(image=image)

    print(emotion)
