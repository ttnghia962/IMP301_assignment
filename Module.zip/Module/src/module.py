import cv2, numpy as np
from collections import Counter
from ultralytics import YOLO
from pathlib import Path


class Module:
    def __init__(self, model: str):
        self.model = YOLO(model=model)

    def __call__(self, image: Path | str | np.ndarray):
        results = self.model.predict(source=image, conf=0.7)
        classes_id = self.model.names
        names = []

        for r in results:
            for c in r.boxes.cls:
                names.append(classes_id[int(c)])

        return Counter(names).most_common(1)[0][0]
