from ultralytics import YOLO


def train():
    model = YOLO("weights/yolov8n.pt")

    model.train(
        data="/home/tuan/Documents/Module/dataset/data.yaml",
        epochs=100,
        patience=10,
        batch=128,
        device="cpu",
        optimizer="AdamW",
        dropout=0.5,
        freeze=True,
        verbose=True,
    )


if __name__ == "__main__":
    train()
