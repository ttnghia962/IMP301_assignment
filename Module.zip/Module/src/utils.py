# Convert norm scale to original scale
def normalized_to_original(
    x_center_normalized,
    y_center_normalized,
    width_normalized,
    height_normalized,
    image_width,
    image_height,
):
    x_center = x_center_normalized * image_width
    y_center = y_center_normalized * image_height
    width = width_normalized * image_width
    height = height_normalized * image_height

    return x_center, y_center, width, height


# Crop face from image
def crop_image_with_bounding_boxes(image, boxes):
    cropped_images = []

    for box in boxes:
        x_center, y_center, width, height = box
        x_min = int(x_center - (width / 2))
        y_min = int(y_center - (height / 2))
        x_max = int(x_center + (width / 2))
        y_max = int(y_center + (height / 2))

        cropped_image = image[y_min:y_max, x_min:x_max]
        cropped_images.append(cropped_image)

    return cropped_images
